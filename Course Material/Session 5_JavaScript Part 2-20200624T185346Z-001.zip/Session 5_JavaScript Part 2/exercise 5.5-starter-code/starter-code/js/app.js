
// FUNCTIONS EXERCISE

// 1. Write a function that reverses a string


// 2. Write a function that sorts a string in alphabetical order


// 3. Write a function that loops over an array or Strings and capitalises each one before returning the array 


// 4. Write a function that console logs the data type of the aruments


// 5. Write a function that returns the length of the longest word in a sentence
