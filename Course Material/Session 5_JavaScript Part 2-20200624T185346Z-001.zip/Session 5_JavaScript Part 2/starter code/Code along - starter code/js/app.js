/* eslint-disable no-unused-vars */


// Your code goes here

// Exercise: FUNCTIONS

// Exercise: ARGUMENTS

// Passing Variables as arguments when we invoke the function

// Exercise: CONTROL FLOW

// ADDING LOGIC(code available on slides)

// Exercise: FUNCTION LOGIC


// SCOPE (code available on slides)
